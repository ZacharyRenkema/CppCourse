#ifndef CSTRING_H
#define CSTRING_H

unsigned int length(char str[]);
unsigned int find(char str[], char character);
bool equalStr(char str1[], char str2[]);

#endif