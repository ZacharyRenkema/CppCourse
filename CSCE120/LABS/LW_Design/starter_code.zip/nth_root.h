#ifndef NTH_ROOT_H
#define NTH_ROOT_H

double nth_root(int n , double x);

#endif  // NTH_ROOT_H