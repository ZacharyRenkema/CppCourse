# include "functions.h"
// add any includes

using std::cout, std::cin, std::endl, std::string;

void deobfuscate() {
    // TODO
}

void wordFilter() {
    // TODO
}

void passwordConverter() {
    // TODO
}

void wordCalculator() {
    // TODO
}

void palindromeCounter() {
    // TODO
}